﻿须知

1. index.html文件可以直接在本机浏览器上打开，本地预览时推荐使用这种方式；
2. 如果需要部署到远程服务器，请将本目录下所有文件都拷贝到服务器上，删除index.html，将remote.html重命名为index.html，然后使用远程地址访问即可；
3. 自行部署到服务器时，请添加 .woff, .woff2, .ttf 三种后缀名的 MIME-TYPE：
    - 后缀名：.woff
    - MIME类型：application/x-font-woff

    - 后缀名：.woff2
    - MIME类型：application/x-font-woff

    - 后缀名：.ttf
    - MIME类型：application/x-font-ttf
4. 如需帮助，请加Mockplus官方QQ群，或Email至service@jongde.com。
